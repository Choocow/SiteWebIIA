# About 
In this repo I was given a Task to create a Login and Registration page which will reflect all the baiscs I have learned in the first week and I have also learned React-router along with this task as I had to implement it. Screen-shots are below:
<img src="https://user-images.githubusercontent.com/46750877/147804462-e479fb63-05ef-4e14-a320-a47df726254d.PNG" height="500" width="700">
- On clicking on the Login button it will go to home page
- And clicking the "register nor" it will go to registration form
<img src="https://user-images.githubusercontent.com/46750877/147804459-1cab4358-acba-4335-b324-a5e05aa6d180.PNG" height="500" width="700">
- On clicking Register button it will go to Home page
- And clicking the "Login!!" it will go to Login form
<img src="https://user-images.githubusercontent.com/46750877/147804461-a444f7c0-5925-433f-97dc-04a4335e365b.PNG" height="300" width="700">

NOTE: Authentication is not done in this Task

