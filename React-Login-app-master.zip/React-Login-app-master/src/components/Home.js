import React from 'react'
import 'react-router-dom'

function Home() {
    return (
        <div>
            <h1>Hello Welcome !!! </h1>
        </div>
    )
}

export default Home
