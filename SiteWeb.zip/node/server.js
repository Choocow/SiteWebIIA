const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const cors = require('cors');
const path = require('path');//
const { expressjwt: jwt } = require("express-jwt");
const port = 8080;
const pathDir = __dirname + "/public/src/views/"; //


const loginController = require('./controller/login-controller');
const userController = require('./controller/user-controller');
const caController = require('./controller/ca-controller');

// Paramètres BODY
app.use(bodyParser.json());


// Paramètres CORS
app.use(cors());
app.use('/static', express.static(__dirname + '/public'));//
app.use("/node_modules", express.static(__dirname + "/node_modules"));


// Routes
app.get('/', function(req, res) { //
  res.set('Content-Type', 'text/html');
  res.sendFile(__dirname + "/public/index.html");
});

app.get('/login', function(req, res) { //
  res.set('Content-Type', 'text/html');
  res.sendFile(pathDir + "/static/LoginView.vue");
});

app.post("/auth", loginController.authProcess);
app.post("/forgot", loginController.checkEmail);
app.get("/api/user", userController.findAll);
app.get("/api/user/:id", userController.findById);
app.post("/api/user", userController.create);
app.post("/api/user/:id", userController.edit);
app.delete("/api/user/:id", userController.deleteById);
app.post("/api/ca", caController.findByDate);

// Protection JWT
app.use(
  jwt({
    secret: "shhhhhhared-secret",
    algorithms: ["HS256"],
  }).unless({ path: [ "/auth", "/", "/static/", "/oublier"  ] })
);



// Démarrage du serveur
app.listen(port, () => {
  console.log(`Express runs on http://localhost:${ port }/`);
});