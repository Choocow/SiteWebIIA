<template>
  <div class="container">
    <RouterView />
  </div>
</template>