import { useUserStore } from '../stores/user';

export default {
  handle() {
    const userStore = useUserStore();

    return userStore.isAuthenticated;
  },

  route() {
    return { name: 'login' };
  }
}