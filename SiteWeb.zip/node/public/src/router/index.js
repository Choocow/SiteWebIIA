import { createRouter, createWebHistory } from 'vue-router';
import LoginView from '/src/views/LoginView.vue';
import HomeView from '/src/views/HomeView.vue';
import OublierView from '/src/views/OublierView.vue';

import AuthFilter from './filters/auth';

const routes = [
  {
    path: '/',
    name: 'home',
    meta: {
      filters: [ AuthFilter ]
    },
    component: HomeView
  },
  {
    path: '/add',
    name: 'add',
    meta: {
      filters: [ AuthFilter ]
    },
    component: EditView
  },
  // {
  //   path: '/edit/:id',
  //   name: 'edit',
  //   meta: {
  //     filters: [ AuthFilter ]
  //   },
  //   component: EditView
  // },
  {
    path: '/login',
    name: 'login',
    component: LoginView
  },
  {
    path: '/oublier',
    name: 'oublier',
    component: OublierView
  }
];

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes
});

router.beforeEach(async to => {
  if (to.meta.filters) {
    for (const filter of to.meta.filters) {
      if (!filter.handle()) {
        return filter.route();
      }
    }
  }
});

export default router;
