import { createApp } from '../../node_modules/vue/dist/vue.cjs.js';
import { createPinia } from '../../node_modules/pinia/index.js';

import App from './App.vue';
import router from './router/index.js';
import axios from '../../node_modules/axios/index.js';

const app = createApp(App);
const pinia = createPinia();

axios.defaults.baseURL = import.meta.env.VITE_API_URL;

app.use(pinia);
app.use(router);

app.mount('#app');
