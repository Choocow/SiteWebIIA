import { ref } from 'vue';
import { defineStore } from 'pinia';
import axios from 'axios';

export const caStore = defineStore('ca', () => {
    const caList = ref(null); 
    async function dateList(dateDeb, dateFin) {
    try {
        const resp = await axios.post('/api/ca', {
        dateDeb, dateFin
        });
        console.log(resp);

        return true;
    }

    catch {
        return false;
    }
    }

    return { caList, dateList };
});