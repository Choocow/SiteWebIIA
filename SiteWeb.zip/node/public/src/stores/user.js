import { ref } from 'vue';
import { defineStore } from 'pinia';
import axios from 'axios';

export const useUserStore = defineStore('user', () => {
  const isAuthenticated = ref(false);
  const token = ref(null);

  async function auth(username, password) {
    try {
      const resp = await axios.post('/auth', {
        username, password
      });

      isAuthenticated.value = !!resp.data.token;
      token.value = resp.data.token;

      applyAuthorizationHeader();

      return isAuthenticated.value;
    }

    catch {
      return false;
    }
  }

  

  function applyAuthorizationHeader() {
    if (token.value) {
      axios.defaults.headers.common = { 'Authorization': `Bearer ${ token.value }` };

      axios.interceptors.response.use(response => response, error => {
        if (error.response.status == 401 && this.$route.name != 'login') {
          this.$router.push({ name: 'notfound' });
        }

        if (error.response.status == 403) {
          this.$router.push({ name: 'login' });
        }
      });

      return true;
    }

    return false;
  }

  return { isAuthenticated, auth };
});
