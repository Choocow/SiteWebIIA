<template>
  <h1>Chiffres D'affaires</h1>
  <div>
    <label for="dateDeb">Date début</label>
    <input v-model="userForm.dateDeb" type="date" id="dateDeb" name="dateDeb">

    <label for="dateFin">Date fin</label>
    <input v-model="userForm.dateFin" type="date" id="dateFin" name="dateFin">

    <label for="region">Region</label>
    <input v-model="userForm.region" type="text" id="region" name="region">
  </div>



  <div>
    <button @click="filtre()" class="btn btn-success" style="display: block; margin-left: auto; margin-right: auto; background-color: rgb(241, 72, 6) !important; margin-bottom: 20px;">Filtrer</button>
  </div>

  <label id="result"> </label>
</template>

<script setup>
import axios from 'axios';
import { ref, reactive } from 'vue';
import { caStore } from '@/stores/ca';
import { useRouter } from 'vue-router';
// const caStore = require("@/stores/ca");
const router = useRouter();
const userForm = reactive({
  dateDeb: "",
  dateFin: "",
  region: ""
});

async function filtre() {
  document.getElementById('result').innerHTML = "";
  var ca = await dateList(userForm.dateDeb, userForm.dateFin, userForm.region); 
  if(ca) {
    const array = ca.data.ca;

    array.forEach((element) => {
      document.getElementById('result').innerHTML += "||| Date: " + element.date+ "| Region: " + element.region + "| Vendeur: " + element.vendeur + "| Montant: " + element.montant + "\n"; 
    });
  }
}

async function dateList(dateDeb, dateFin, region) {
      const resp = (await axios.post('/api/ca', {
      dateDeb, dateFin, region
      }));

      return resp;
    }

</script>
