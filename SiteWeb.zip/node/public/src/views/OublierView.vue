<template>
    <div class="vh-100 d-flex justify-content-center align-items-center">
      <div class="card">
        Entrer votre Adresse Mail
  
        <div class="card-body">
          <div v-if="loggingError" class="alert alert-danger" role="alert">
            Echec de connexion
          </div>
  
          <input v-model="userForm.email" class="form-control mb-2" placeholder="Adresse Mail" />
        </div>
        
        <div>
          <button @click="oublier()" class="btn btn-success" style="background-color: rgb(241, 72, 6) !important">Envoyer un mail</button>
        </div>
      </div>

    </div>
  </template>
  
  <script setup>
  import { ref, reactive } from 'vue';
  import { useUserStore } from '@/stores/user';
  import { useRouter } from 'vue-router';
  import axios from 'axios';
  
  const router = useRouter();
  const loggingError = ref(false);
  const userForm = reactive({
    email: ""
  });
  const userStore = useUserStore();
  
  
  async function oublier() {
    console.log(userForm.email);
    loggingError.value = false;
    loggingError.value = !(await verifyEmail(userForm.email));
    console.log(loggingError.value);
  
    if (!loggingError.value) {
      console.log("Email envoyé !");

      const nodemailer = require('nodemailer');
      const transporter = nodemailer.createTransport({
        host: 'smtp.gmail.com',
        port: 587,
        auth: {
          user: '0aguio0@gmail.com',
          pass: 'B97k8xhh/',
        },
      });
      
      transporter.verify().then(console.log).catch(console.error);

      transporter.sendMail({
        from: '"Your Name" <0aguio0@gmail.com>', // sender address
        to: "0aguio0@gmail.com", // list of receivers
        subject: "Medium @edigleyssonsilva ✔", // Subject line
        text: "There is a new article. It's about sending emails, check it out!", // plain text body
        html: "<b>There is a new article. It's about sending emails, check it out!</b>", // html body
      }).then(info => {
        console.log({info});
      }).catch(console.error);
    }
  }
  </script>
  
  <style>
  .card {
    width: 400px;
  }
  </style>