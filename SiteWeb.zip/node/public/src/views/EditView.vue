<template>
  <div class="vh-100 d-flex justify-content-center align-items-center">
    <div class="card">
      <div class="card-header">
        <template v-if="$route.params.id">Editer un utilisateur</template>
        <template v-else>Ajouter un utilisateur</template>
      </div>

      <div class="card-body">
        <input v-model="userForm.username" class="form-control mb-2" placeholder="Nom d'utilisateur" />
        <input v-model="userForm.password" class="form-control" type="password" placeholder="Mot de passe" />
      </div>
      
      <div class="card-footer">
        <button @click="addOrEdit()" class="btn btn-success">
          <template v-if="$route.params.id">Modifier</template>
          <template v-else>Ajouter</template>
        </button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { onMounted, reactive } from 'vue';
import axios from 'axios';

import { useRoute, useRouter } from 'vue-router';

const route = useRoute();
const router = useRouter();
const userForm = reactive({
  username: "",
  password: ""
});

onMounted(async () => {
  if (route.params.id) {
    const resp = await axios.get(`/user/${ route.params.id }`);

    userForm.username = resp.data.username;
  }
});

async function addOrEdit() {
  try {
    if (route.params.id) {
      await axios.put(`/user/${ route.params.id }`, userForm);
    }
    
    else {
      await axios.post(`/user`, userForm);
    }

    router.push({ name: 'home' });
  }

  catch { }
}
</script>

<style>
.card {
  width: 400px;
}
</style>