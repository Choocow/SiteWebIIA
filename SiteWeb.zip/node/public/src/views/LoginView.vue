<template>
  <div class="vh-100 d-flex justify-content-center align-items-center">
    <div class="card">
      <div>
      </div>
      <div style="display: block; margin-left: auto; margin-right: auto; margin-top: 20px;">
        <img src='/static/images/icon.jpg' alt='profile'/>
        <h3 style="text-align: center;">Login</h3>
      </div>
      <div class="card-body">
        <div v-if="loggingError" class="alert alert-danger" role="alert">
          Echec de connexion
        </div>
        <div>
          <img src='/static/images/email.png' alt='profile' className='profile' style="height: 25px; width: 35px;" />
          <input v-model="userForm.username" class="form-control mb-2" placeholder="Nom d'utilisateur" style="padding-left: 70px; font-size: 20px;"/>
        </div>
        <div>
          <img src='/static/images/lock.png' alt='password' className='email' style="height: 25px; width: 35px;" />
          <input v-model="userForm.password" class="form-control" type="password" placeholder="Mot de passe" style="padding-left: 70px; font-size: 20px;"/>
        </div>
      </div>
      
      <div>
        <button @click="login()" class="btn btn-success" style="display: block; margin-left: auto; margin-right: auto; background-color: rgb(241, 72, 6) !important; margin-bottom: 20px;">Login</button>
      </div>
      <div>
        <button @click="oublier()" class="btn btn-success" style="display: block; margin-left: auto; margin-right: auto; background-color: rgb(241, 72, 6) !important; margin-bottom: 20px;">Mot de passe oublier</button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive } from 'vue';
import { useUserStore } from '@/stores/user';
import { useRouter } from 'vue-router';

const router = useRouter();
const loggingError = ref(false);
const userForm = reactive({
  username: "",
  password: ""
});
const userStore = useUserStore();

async function login() {
  loggingError.value = false;
  loggingError.value = !(await userStore.auth(userForm.username, userForm.password));

  if (!loggingError.value) {
    router.push({ name: 'home' });
  }
}

async function oublier() {
  router.push({ name: 'oublier'});
}
</script>

<style>
.card {
  width: 400px;
}
</style>