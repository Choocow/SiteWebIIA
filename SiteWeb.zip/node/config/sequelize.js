const { Sequelize } = require('sequelize');

module.exports = new Sequelize('mysql://root:root@127.0.0.1/SiteWeb');
