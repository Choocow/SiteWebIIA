const srvCA = require('../service/ca-service');

module.exports = {
  async findAll(req, res) {
    const ca = await srvCA.findAll();
    const data = [];

    for (let chiffre_daffaire of ca) {
      data.push({
        idCA: ca.idCA,
        date: ca.date,
        region: ca.region,
        vendeur: ca.vendeur,
        montant: ca.montant
      });
    }

    res.send(data);
  },

  async findById(req, res) {
    const ca = await srvCA.findById(req.params.id);

    if (!ca) {
      res.status(404).send({ success: false });
      return;
    }

    res.send({
      idCA: ca.idCA,
      date: ca.date,
      region: ca.region,
      vendeur: ca.vendeur,
      montant: ca.montant
    });
  },

  async findByRegion(req, res) {
    const ca = await srvCA.findByRegion(req.params.region);

    if (!ca) {
      res.status(404).send({ success: false });
      return;
    }

    res.send({
      idCA: ca.idCA,
      date: ca.date,
      region: ca.region,
      vendeur: ca.vendeur,
      montant: ca.montant
    });
  },

  async findByVendeur(req, res) {
    const ca = await srvCA.findByVendeur(req.params.region);

    if (!ca) {
      res.status(404).send({ success: false });
      return;
    }

    res.send({
      idCA: ca.idCA,
      date: ca.date,
      region: ca.region,
      vendeur: ca.vendeur,
      montant: ca.montant
    });
  },

  async findByDate(req, res) {
    console.log(req);
    console.log(req.dateDeb);
    const ca = await srvCA.findByDate(req.body.dateDeb, req.body.dateFin, req.body.region);
    console.log("test controller");
    if (!ca) {
      res.status(404).send({ success: false });
      return;
    }
    console.log(ca.data);
    console.log(typeof ca);
    console.log("test controller 2");
    res.send({
      ca: ca
    });
  }

};