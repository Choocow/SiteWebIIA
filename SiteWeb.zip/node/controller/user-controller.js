const srvUser = require('../service/user-service');
const bcrypt = require("../node_modules/bcrypt/bcrypt");

async function hashPassword(user, password) {
  if (password) {
    const salt = await bcrypt.genSalt(10);
    const hash = await bcrypt.hash(password, salt);
    
    user.password = hash;
  }
}

module.exports = {
  async findAll(req, res) {
    const users = await srvUser.findAll();
    const data = [];

    for (let user of users) {
      data.push({
        id: user.id,
        username: user.username
      });
    }

    res.send(data);
  },

  async findById(req, res) {
    const user = await srvUser.findById(req.params.id);

    if (!user) {
      res.status(404).send({ success: false });
      return;
    }

    res.send({
      id: user.id,
      username: user.username
    });
  },

  async findByEmail(req, res) {
    const user = await srvUser.findByEmail(req.params.email);

    if (!user) {
      res.status(404).send({ success: false });
      return;
    }

    res.send({
      id: user.id,
      username: user.username
    });
  },

  async create(req, res) {
    let user = {
      username: req.body.username
    }

    await hashPassword(user, req.body.password);

    user = await srvUser.save(user);
    
    res.send({
      id: user.id,
      username: user.username
    });
  },

  async edit(req, res) {
    // let user = await srvUser.findById(req.params.id);
    console.log(req.id);
    let user = await srvUser.findById(req.id);
    console.log(user);
    if (!user) {
      res.status(404).send({ success: false });
      return;
    }

    user.username = req.username;

    if (req.password) {
      await hashPassword(user, req.password);
    }

    user = await srvUser.save(user);
    
    // res.send({
    //   id: user.id,
    //   username: user.username
    // });
  },

  async deleteById(req, res) {
    await srvUser.deleteById(req.params.id);

    res.send(true);
  },

  async hash(user, password) {
    if (password) {
      try{
      const hashget = await bcrypt.hash(password, 10, function(err, hash) {
        if (err) { throw (err); }
        console.log("3", hash);
        user.password = hash;
        user = srvUser.save(user);

        return true;
      });
      } catch(error) {
        return error;
      }
    }
  },

  async compare(password, id, username) {
    console.log("5", password);
    try{

    let user = await srvUser.findByUsername(username);

    console.log("6", user);
    console.log("7", user.password);

    try{

      const compare = await bcrypt.compare(password, user.password, function(err, result) {
        if (err) { throw (err); }
        console.log("8", result);
        return result;
      });

      }catch(error) {
        return error;
      }


    }catch(errorUser) {
      return errorUser;
    }


  }
};
