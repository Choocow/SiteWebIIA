const srvUser = require('../service/user-service');
const jwt = require('jsonwebtoken');
const bcrypt = require('../node_modules/bcrypt/bcrypt');
const userController = require('../controller/user-controller');
const axios = require('axios');

module.exports = {
  async authProcess(req, res) {
    let user = await srvUser.findByUsername(req.body.username);
    console.log("1", req.body.username); //
    console.log("2", req.body.password);
    if (!user) {
      res.status(401).send({ success: false });
      return;
    }

    const id = user.id;
    const username = req.body.username;
    const password = req.body.password;
    //Hash Password
    // const hashPass = await userController.hash(user, req.body.password);
    const hashPass = await userController.edit({id, username, password  });

    //
    user = await srvUser.findByUsername(req.body.username);
    console.log("4" , req.body.password);
    console.log(user.password);

    const comparePassword = await bcrypt.compare(req.body.password, user.password, function(err, result) {
      if (err) { throw (err); }
      console.log("8", result);

      if (!result) {
        res.status(401).send({ success: false });
        return;
      }
    });

    
    const token = jwt.sign({ username: user.username }, 'shhhhhhared-secret', { algorithm: 'HS256' });

    res.send({
      success: true,
      token
    });
  },

  
  async checkEmail(req, res) {
    console.log("1", req.body.email); //
    let user = await srvUser.findByEmail(req.body.email);
    
    if (!user) {
      res.status(401).send({ success: false });
      return;
    }

    const id = user.id;
    const email = req.body.email;

    
    const token = jwt.sign({ username: user.username }, 'shhhhhhared-secret', { algorithm: 'HS256' });

    res.send({
      success: true,
      token
    });
  }
};
