const User = require("../model/user");

module.exports = {
  findAll() {
    return User.findAll();
  },

  findById(id) {
    return User.findByPk(id);
  },

  findByUsername(username) {
    return User.findOne({ where: { username } });
  },

  findByEmail(mail) {
    return User.findOne({ where: { mail } });
  },

  save(user) {
    if (user.isNewRecord === false) {
      return user.save();
    }

    return User.create(user);
  },

  deleteById(id) {
    return User.destroy({ where: { id } });
  }
}