const Ca = require("../model/ca");
const sequelize = require('sequelize')
const Op = sequelize.Op;

module.exports = {
  findAll() {
    return Ca.findAll();
  },

  findById(id) {
    return Ca.findByPk(id);
  },

  findByRegion(region) {
    return Ca.findAll({ where: { region } });
  },

  findByVendeur(vendeur) {
    return Ca.findAll({ where: { vendeur } });
  },

  findByDate(dateDeb, dateFin, region) {
    console.log(dateDeb);
    console.log(dateFin);
    if(region == undefined || region == ""){
    return Ca.findAll({ where: { 
      date: {
            [Op.gt]: dateDeb,
            [Op.lt]: dateFin
            }
        }, 
        raw: true,
    }

    );
  }else{
    return Ca.findAll({ where: { 
        date: {
              [Op.gt]: dateDeb,
              [Op.lt]: dateFin
              },
        region
      }, 
      raw: true,
    }

    );
  }
  },

  save(ca) {
    if (ca.isNewRecord === false) {
      return ca.save();
    }

    return Ca.create(ca);
  }
}