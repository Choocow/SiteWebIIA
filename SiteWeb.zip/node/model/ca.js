const { Model, DataTypes } = require('sequelize');
const sequelize = require('../config/sequelize');

class chiffre_daffaire extends Model {}

chiffre_daffaire.init({
  idCA:  {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  date: DataTypes.DATE,
  region: DataTypes.STRING,
  vendeur: DataTypes.INTEGER,
  montant: DataTypes.DOUBLE
},
{
  sequelize,
  modelName: 'chiffre_daffaire',
  tableName: 'chiffre_daffaire',
  timestamps: false
});

module.exports = chiffre_daffaire;