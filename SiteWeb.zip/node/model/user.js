const { Model, DataTypes } = require('sequelize');
const sequelize = require('../config/sequelize');

class User extends Model {}

User.init({
  id:  {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  username: DataTypes.STRING,
  password: DataTypes.STRING,
  mail: DataTypes.STRING
},
{
  sequelize,
  modelName: 'user',
  tableName: 'user',
  timestamps: false
});

module.exports = User;