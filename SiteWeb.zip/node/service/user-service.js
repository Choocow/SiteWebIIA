const repoUser = require('../repo/user-repository');

module.exports = {
  findAll() {
    return repoUser.findAll();
  },

  findById(id) {
    return repoUser.findById(id);
  },

  findByUsername(username) {
    return repoUser.findByUsername(username);
  },

  findByEmail(mail) {
    return repoUser.findByEmail(mail);
  },

  save(user) {
    return repoUser.save(user);
  },

  deleteById(id) {
    return repoUser.deleteById(id);
  }
};
