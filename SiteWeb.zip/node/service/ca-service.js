const repoCA = require('../repo/ca-repository');

module.exports = {
  findAll() {
    return repoCA.findAll();
  },

  findById(id) {
    return repoCA.findById(id);
  },

  findByRegion(region) {
    return repoCA.findByRegion(region);
  },

  findByVendeur(vendeur) {
    return repoCA.findByVendeur(vendeur);
  },

  findByDate(dateDeb, dateFin, region) {
    return repoCA.findByDate(dateDeb, dateFin, region);
  },

  save(user) {
    return repoCA.save(user);
  }

};
